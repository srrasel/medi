<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div class="latepoint-message latepoint-message-error"><?php esc_html_e('You are not allowed to access this page', 'latepoint'); ?></div>